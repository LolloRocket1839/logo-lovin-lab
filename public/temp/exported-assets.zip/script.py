
# Correggiamo i dati e aggiorniamo il testo per riflettere correttamente il modello di JungleRent
# dove gli investitori non possiedono gli asset ma percepiscono i redditi attraverso 
# strumenti finanziari partecipativi della società che detiene la proprietà

# Verifichiamo i dati principali con formato sentence case italiano

schema_modello_junglerent = {
    'Elemento': [
        'Proprietà immobili',
        'Gestione operativa',
        'Manutenzione e servizi',
        'Selezione inquilini',
        'Riscossione affitti',
        'Posizione investitore',
        'Strumento investimento',
        'Percezione redditi',
        'Rischio operativo',
        'Liquidità capitale',
        'Controllo diretto'
    ],
    'Modalit\u00e0 Tradizionale': [
        'Investitore proprietario',
        'Gestione diretta o delegata',
        'A carico investitore/gestore',
        'Responsabilit\u00e0 investitore',
        'Incasso diretto',
        'Proprietario asset',
        'Proprietà immobiliare',
        'Canone mensile + valorizzazione',
        'Alto (diretto)',
        'Bassa (real estate illiquido)',
        'Alto'
    ],
    'Modello JungleRent': [
        'Propriet\u00e0 JungleRent società',
        'JungleRent società',
        'JungleRent società',
        'JungleRent società',
        'JungleRent società',
        'Investitore partecipe della società',
        'Strumenti finanziari partecipativi',
        'Distribuzione utili dalla società',
        'Basso (delegato a JungleRent)',
        'Media (strumenti finanziari)',
        'Basso (affidato a società)'
    ]
}

import pandas as pd
df_modello = pd.DataFrame(schema_modello_junglerent)
print("CONFRONTO MODELLO INVESTIMENTO TRADIZIONALE VS JUNGLERENT")
print("=" * 120)
print(df_modello.to_string(index=False))
print("\n")

df_modello.to_csv('modello_junglerent_vs_tradizionale.csv', index=False)

# Dati specifici per investitori in JungleRent tramite strumenti partecipativi
junglerent_investimento = {
    'Aspetto dell\'investimento': [
        'Capitale minimo investibile',
        'Forma di investimento',
        'Proprietà dell\'asset',
        'Gestione asset',
        'Responsabilità manutenzione',
        'Commercializzazione stanze',
        'Gestione contratti',
        'Rischio locativo',
        'Rendimento lordo atteso',
        'Periodo di distribuzione',
        'Meccanismo exit',
        'Trasparenza operativa'
    ],
    'Valore/Descrizione': [
        '10.000-100.000 euro',
        'Quota di strumenti partecipativi in JungleRent',
        'JungleRent (società proprietaria)',
        'Completamente delegata a JungleRent',
        'A carico JungleRent',
        'JungleRent professionalmente',
        'JungleRent secondo standard',
        'Assorbito da JungleRent',
        '8-12% annuo da distribuzione utili',
        'Semestrale o annuale',
        'Riscatto quota o vendita pacchetto',
        'Dashboard digitale con monitoring'
    ]
}

df_junglerent = pd.DataFrame(junglerent_investimento)
print("CARATTERISTICHE INVESTIMENTO IN JUNGLERENT - STRUMENTI PARTECIPATIVI")
print("=" * 120)
print(df_junglerent.to_string(index=False))
print("\n")

df_junglerent.to_csv('junglerent_caratteristiche_investimento.csv', index=False)

print("File CSV aggiornati con successo!")
